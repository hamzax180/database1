const express = require('express');
const { MongoClient } = require('mongodb');
const app = express();
const port = 3000;


app.use(express.json());


const uri = "mongodb://localhost:12345";
const client = new MongoClient(uri);

async function main() {
    try {
        await client.connect();
        console.log("Connected to MongoDB");
        
        
        const db = client.db("bank");
        const accounts = db.collection("accounts");

        
        app.post('/accounts', async (req, res) => {
            const newAccount = req.body;
            const result = await accounts.insertOne(newAccount);
            res.status(201).send(result);
        });

        app.get('/accounts', async (req, res) => {
            const allAccounts = await accounts.find({}).toArray();
            res.status(200).send(allAccounts);
        });

        
        

    } catch (e) {
        console.error(e);
    }
}

main();

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
