

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('accountForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const buttonLabel = document.getElementById('formButton').textContent;
        if (buttonLabel === 'Create Account') {
            createAccount();
        } else if (buttonLabel === 'Save Changes') {
            saveChanges();
        }
    });
});

function createAccount() {
    const accountNumber = document.getElementById('accountNumber').value;
    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const balance = document.getElementById('balance').value;
    const newAccount = { accountNumber, name, address, phoneNumber, balance };
    addAccountToList(newAccount);
    resetForm();
}

function addAccountToList(account) {
    const table = document.getElementById('accountsTable');
    const newRow = table.insertRow(-1);
    newRow.insertCell(0).textContent = account.accountNumber;
    newRow.insertCell(1).textContent = account.name;
    newRow.insertCell(2).textContent = account.address;
    newRow.insertCell(3).textContent = account.phoneNumber;
    newRow.insertCell(4).textContent = account.balance;
    const actionsCell = newRow.insertCell(5);
    actionsCell.innerHTML = `<button onclick="editAccount(this.parentNode.parentNode)">Edit</button>
                             <button onclick="deleteAccount(this.parentNode.parentNode)">Delete</button>`;
}

function editAccount(row) {
    document.getElementById('accountNumber').value = row.cells[0].textContent;
    document.getElementById('name').value = row.cells[1].textContent;
    document.getElementById('address').value = row.cells[2].textContent;
    document.getElementById('phoneNumber').value = row.cells[3].textContent;
    document.getElementById('balance').value = row.cells[4].textContent;
    document.getElementById('formButton').textContent = 'Save Changes';
    document.getElementById('accountForm').dataset.editRowIndex = row.rowIndex;
}

function saveChanges() {
    const rowIndex = document.getElementById('accountForm').dataset.editRowIndex;
    const table = document.getElementById('accountsTable');
    const row = table.rows[rowIndex];
    row.cells[1].textContent = document.getElementById('name').value;
    row.cells[2].textContent = document.getElementById('address').value;
    row.cells[3].textContent = document.getElementById('phoneNumber').value;
    row.cells[4].textContent = document.getElementById('balance').value;
    resetForm();
}

function deleteAccount(row) {
    document.getElementById('accountsTable').deleteRow(row.rowIndex);
}

function resetForm() {
    document.getElementById('accountForm').reset();
    document.getElementById('formButton').textContent = 'Create Account';
    delete document.getElementById('accountForm').dataset.editRowIndex;
}


function deleteAccount(row) {
    document.getElementById('accountsTable').deleteRow(row.rowIndex);
}

function resetForm() {
    document.getElementById('accountForm').reset();
    document.getElementById('formButton').textContent = 'Create Account';
    delete document.getElementById('accountForm').dataset.editRowIndex;
}


